from bouncing_alien import *
main()
