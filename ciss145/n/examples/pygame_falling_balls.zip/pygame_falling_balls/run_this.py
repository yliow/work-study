from pygame_falling_balls import run
run()
