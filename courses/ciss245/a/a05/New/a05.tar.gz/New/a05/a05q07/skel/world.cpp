/*********************************************************************

File  : world.cpp
Author:

Implementation of world.h.

*********************************************************************/
#include <iostream>
#include "world.h"

void init(char world[10][10])
{
}

// Other functions ...
