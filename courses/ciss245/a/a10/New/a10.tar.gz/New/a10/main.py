s = open('diagram25.py', 'r').read()
from latextool_basic import *
execute(s)

