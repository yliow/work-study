from latextool_basic import *
p, q = (0,0), (2,3)
print(plot(vector=[p,q]))

