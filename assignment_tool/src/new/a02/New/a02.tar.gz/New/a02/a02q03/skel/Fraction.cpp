// File: Fraction.cpp

void Fraction_print(int n, int d)
{
}


void Fraction_add(int & xn, int & xd,
                  int yn, int yd,
                  int zn, int zd)
{
}


void Fraction_sub(int & xn, int & xd,
                  int yn, int yd,
                  int zn, int zd)
{
}
