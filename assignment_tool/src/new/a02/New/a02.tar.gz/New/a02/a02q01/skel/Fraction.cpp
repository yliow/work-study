
// File: Fraction.cpp
// Author: smaug

#include <iostream>


void Fraction_print(int n, int d)
{
}
