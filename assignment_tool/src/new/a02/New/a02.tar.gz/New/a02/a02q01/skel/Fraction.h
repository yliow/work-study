// File: Fraction.h
// Author: smaug

//-----------------------------------------------------------------------------
// Print fraction modeled by numerator n and denominator d.
//-----------------------------------------------------------------------------
void Fraction_print(int, int);
