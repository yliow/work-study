# depends on file structure
name = "yliow"
courses = "ciss350"
assignment = "a01"

dir = [("induction.tex", 'nln'),
       ("a02q01/q01.tex", 'nln'),
       ("a02q01/q01s.tex", 'sln'),
       ("primes.tex", 'nln'),
       ("a02q02/q02.tex", 'nln'),
       ("a02q02/q02s.tex", 'sln'),
       ("a02q03/q03.tex", 'nln'),
       ("a02q03/q03s.tex", 'sln')
       ]

